﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class FlashPanel : MonoBehaviour {

    Image thisImage;

    // Color shifting variables
    Color csOriginal;
    float csTime;
    bool csActive = false;

    void Start ()
    {
        thisImage = GetComponent<Image>();

        csOriginal = thisImage.color;
    }

	void Update () {
	}

    public void ColorShift(Color targetColor, float incTime)
    {   // Turn the panel a color, then fade back to original
        csOriginal = thisImage.color;
        thisImage.color = targetColor;

        StartCoroutine(csReset(incTime));
    }

    IEnumerator csReset(float incTime)
    {
        yield return new WaitForSeconds(incTime);
        thisImage.color = csOriginal;
    }
}
